﻿using System.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.Server;
using System.ComponentModel;
using System.Text.Json;
using System.Data.SqlClient;
using System.Data;
using PdfSharp.Drawing;
using PdfSharp.Pdf;

var builder = Host.CreateApplicationBuilder(args);
builder.Logging.AddConsole(consoleLogOptions =>
{
    // Configure all logs to go to stderr
    consoleLogOptions.LogToStandardErrorThreshold = LogLevel.Trace;
});

builder.Services
    .AddMcpServer()
    .WithStdioServerTransport()
    .WithToolsFromAssembly();
    // var x = GeneratePDFInvoice.GenerateInvoice(new int[] {1,22});
    // Console.WriteLine(x);
await builder.Build().RunAsync();

[McpServerToolType]
public static class EchoTool
{
    [McpServerTool, Description("Echoes the message back to the client.")]
    public static string Echo(string message) => $"Hello from C#: {message}";

    [McpServerTool, Description("Echoes in reverse the message sent by the client.")]
    public static string ReverseEcho(string message) => new([.. message.Reverse()]);
}

[McpServerToolType]
public static class GeneratePDFInvoice
{
    public static readonly string pdfFilePath = "C:\\Users\\ldas009\\Downloads\\RAG Hack\\Order.pdf";
    [McpServerTool, Description("Generates a PDF invoice from the provided data.")]
    public static string GenerateInvoice(
        [Description("Order IDs for which invoice needs to be generated")] int[] orderIds)
    {
        try
        {
            var orders = FetchOrdersByIds(orderIds);
            Console.WriteLine($"Generating invoice for the following orders: {string.Join(", ", orders.Select(o => o.id))}");
            if (orders.Length == 0)
            {
                // return "No orders found for the provided IDs.";
                GenerateInvoicePdf(orders);
            }

            GenerateInvoicePdf(orders);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error generating invoice: {ex.Message}");
            return $"Error generating invoice: {ex.Message}";
        }
        Console.WriteLine($"Invoice generated successfully at {pdfFilePath}");
        return $"Invoice generated successfully! File path: {pdfFilePath}";
    }

    private static Order[] FetchOrdersByIds(int[] orderIds)
    {
        var connectionString = ConfigurationManager.AppSettings["SqlConnectionString"]
            ?? throw new InvalidOperationException("SqlConnectionString is not configured in AppSettings.");

        var orders = new List<Order>();

        using (var connection = new SqlConnection(connectionString))
        {
            connection.Open();
            var query = $"SELECT top(1) orderID, orderDetails, concat, date, totalPrice FROM dbo.[Invoices] Order By orderID DESC";

            // var query = $"SELECT orderID, orderDetails, concat, date, totalPrice FROM dbo.[Invoices] WHERE orderID IN ({string.Join(",", orderIds)})";
            using (var command = new SqlCommand(query, connection))
            {
                //var parameter = new SqlParameter("@OrderIds", SqlDbType.Int)
                //{
                //    Value = string.Join(",", orderIds)
                //};
                //command.Parameters.Add(parameter);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        orders.Add(new Order
                        {
                            id = reader["orderID"].ToString(),
                            orderDetails = reader["orderDetails"].ToString(),
                            concat = reader["concat"].ToString(),
                            date = DateTime.Parse(reader["date"].ToString()),
                            totalPrice = float.Parse(reader["totalPrice"].ToString())
                        });
                    }
                }
            }
        }

        return orders.ToArray();
    }
    private static string SplitAndKeepFirstHalf(string input)
    {
        if (string.IsNullOrEmpty(input))
            return input;

        int midIndex = input.Length / 2;
        return input.Substring(0, midIndex);
    }
    private static void GenerateInvoicePdf(Order[] orders)
    {
        PdfDocument document = new PdfDocument();
        var page = document.AddPage();
        var gfx = XGraphics.FromPdfPage(page);
        var titleFont = new XFont("Arial", 30, XFontStyleEx.Bold);
        var font = new XFont("Arial", 12);
        var boldFont = new XFont("Arial", 14, XFontStyleEx.Bold);

        // Add "Invoice" title at the top center  
        gfx.DrawString("Invoice", titleFont, XBrushes.Black,
            new XRect(0, 20, page.Width, 40), XStringFormats.TopCenter);

        // Add a separator line below the title  
        gfx.DrawLine(XPens.Black, 20, 60, page.Width - 20, 60);

        double yPoint = 80; // Start below the separator line  

        // Add table headers  
        gfx.DrawString("ID", boldFont, XBrushes.Black, new XPoint(20, yPoint));
        gfx.DrawString("Date", boldFont, XBrushes.Black, new XPoint(150, yPoint));
        gfx.DrawString("Order Details", boldFont, XBrushes.Black, new XPoint(300, yPoint));
        gfx.DrawString("Total Price", boldFont, XBrushes.Black, new XPoint(400, yPoint));
        yPoint += 20;

        float invoiceTotal = 0; // To calculate the total price of all orders  

        foreach (var order in orders)
        {
            // Add order details in table format  
            gfx.DrawString(order.id, font, XBrushes.Black, new XRect(20, yPoint, 50, 20), XStringFormats.CenterLeft);
            gfx.DrawString(order.date.ToString(), font, XBrushes.Black, new XRect(150, yPoint, 120, 20), XStringFormats.TopLeft);
            gfx.DrawString(SplitAndKeepFirstHalf(order.orderDetails), font, XBrushes.Black, new XRect(300, yPoint, 120, 20), XStringFormats.TopLeft);
            gfx.DrawString(order.totalPrice.ToString("F2"), font, XBrushes.Black, new XRect(400, yPoint, 120, 20), XStringFormats.TopLeft);
            yPoint += 20;
            invoiceTotal += order.totalPrice; // Accumulate total price  
        }

        yPoint += 20; // Add some space before the total  

        // Add Invoice Total  
        gfx.DrawString($"Invoice Total: {invoiceTotal:F2}", boldFont, XBrushes.Black, new XPoint(20, yPoint));

        document.Save(pdfFilePath);
    }
}
public static class JsonConverter
{
    public static string ConvertToJson<T>(T obj)
    {
        return JsonSerializer.Serialize(obj, new JsonSerializerOptions { WriteIndented = true });
    }
}

public class Order
{
    public string orderDetails { get; set; }
    public string concat { get; set; }
    public DateTime date { get; set; }
    public float totalPrice { get; set; }
    public string id { get; set; }
}